#experiment on WRN-28-2

import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from scipy.stats import norm
import scipy

import math

def distillation_loss(source, target, margin):
    target = torch.max(target, margin)
    loss = torch.nn.functional.mse_loss(source, target, reduction="none")
    loss = loss * ((source > target) | (target > 0)).float()
    return loss.sum()



class FSP(nn.Module):
    """A Gift from Knowledge Distillation:
    Fast Optimization, Network Minimization and Transfer Learning"""
    def __init__(self, s_shapes, t_shapes):
        super(FSP, self).__init__()
        assert len(s_shapes) == len(t_shapes), 'unequal length of feat list'
        s_c = [s[1] for s in s_shapes]
        t_c = [t[1] for t in t_shapes]
        if np.any(np.asarray(s_c) != np.asarray(t_c)):
            raise ValueError('num of channels not equal (error in FSP)')

    def forward(self, g_s, g_t):
        s_fsp = self.compute_fsp(g_s)
        t_fsp = self.compute_fsp(g_t)
        loss_group = [self.compute_loss(s, t) for s, t in zip(s_fsp, t_fsp)]
        return loss_group

    @staticmethod
    def compute_loss(s, t):
        return (s - t).pow(2).mean()

    @staticmethod
    def compute_fsp(g):
        fsp_list = []
        for i in range(len(g) - 1):
            bot, top = g[i], g[i + 1]
            b_H, t_H = bot.shape[2], top.shape[2]
            if b_H > t_H:
                bot = F.adaptive_avg_pool2d(bot, (t_H, t_H))
            elif b_H < t_H:
                top = F.adaptive_avg_pool2d(top, (b_H, b_H))
            else:
                pass
            bot = bot.unsqueeze(1)
            top = top.unsqueeze(2)
            bot = bot.view(bot.shape[0], bot.shape[1], bot.shape[2], -1)
            top = top.view(top.shape[0], top.shape[1], top.shape[2], -1)

            fsp = (bot * top).mean(-1)
            fsp_list.append(fsp)
        return fsp_list

def spectral_loss(source, target, margin):
    target = torch.max(target, margin)
    loss = torch.nn.functional.mse_loss(source, target, reduction="none")
    loss = loss * ((source > target) | (target > 0)).float()
    return loss.sum()

def build_feature_connector(t_channel, s_channel):
    C = [nn.Conv2d(s_channel, t_channel, kernel_size=1, stride=1, padding=0, bias=False),
         nn.BatchNorm2d(t_channel)]

    for m in C:
        if isinstance(m, nn.Conv2d):
            n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            m.weight.data.normal_(0, math.sqrt(2. / n))
        elif isinstance(m, nn.BatchNorm2d):
            m.weight.data.fill_(1)
            m.bias.data.zero_()

    return nn.Sequential(*C)

def get_margin_from_BN(bn):
    margin = []
    std = bn.weight.data
    mean = bn.bias.data
    for (s, m) in zip(std, mean):
        s = abs(s.item())
        m = m.item()
        if norm.cdf(-m / s) > 0.001:
            margin.append(- s * math.exp(- (m / s) ** 2 / 2) / math.sqrt(2 * math.pi) / norm.cdf(-m / s) + m)
        else:
            margin.append(-3 * s)

    return torch.FloatTensor(margin).to(std.device)


class Distiller(nn.Module):
    def __init__(self, t_net, s_net):
        super(Distiller, self).__init__()

        t_channels = t_net.get_channel_num()
        s_channels = s_net.get_channel_num()

        self.Connectors = nn.ModuleList([build_feature_connector(t, s) for t, s in zip(t_channels, s_channels)])

        teacher_bns = t_net.get_bn_before_relu()
        margins = [get_margin_from_BN(bn) for bn in teacher_bns]
        for i, margin in enumerate(margins):
            self.register_buffer('margin%d' % (i+1), margin.unsqueeze(1).unsqueeze(2).unsqueeze(0).detach())

        self.t_net = t_net
        self.s_net = s_net

    def fsp_matrix(self, fm1, fm2):
        if fm1.size(2) > fm2.size(2):
            fm1 = F.adaptive_avg_pool2d(fm1, (fm2.size(2), fm2.size(3)))

        fm1 = fm1.view(fm1.size(0), fm1.size(1), -1)
        fm2 = fm2.view(fm2.size(0), fm2.size(1), -1).transpose(1, 2)

        fsp = torch.bmm(fm1, fm2) / fm1.size(2)
        return fsp

    def TopEigenvalue(self, K, n_power_iterations=10, dim=1):
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        with torch.no_grad():
            # v = torch.ones(K.shape[0], K.shape[1], 1).to(device)
            v = torch.rand(K.shape[0], K.shape[1], 1).to(device)
            # print(K.size())
            for _ in range(n_power_iterations):
                # v_for_iter = v
                m = torch.bmm(K, v)
                n = torch.norm(m, dim=1).unsqueeze(1)
                v = m / n

            # value_new = torch.bmm(torch.transpose(v_for_iter,1,2),v)
            # value_new = torch.sqrt(value_new)

            value = torch.sqrt(n / torch.norm(v, dim=1).unsqueeze(1))
            # value = n / torch.norm(v, dim=1).unsqueeze(1)

            # print(value_new.size(),value.size(),value_new-value)
        # print(value.shape)
        return value

    def forward(self, x):

        t_feats, t_out = self.t_net.extract_feature(x, preReLU=True)
        s_feats, s_out = self.s_net.extract_feature(x, preReLU=True)
        feat_num = len(t_feats)
        # print(feat_num)
        # print(len(s_feats))

        loss_distill = 0
        loss_spectral = 0
        # loss_largest_eigenvalue = 0
        for i in range(feat_num):
            s_feats[i] = self.Connectors[i](s_feats[i])
            loss_distill += distillation_loss(s_feats[i], t_feats[i].detach(), getattr(self, 'margin%d' % (i+1))) \
                            / 2 ** (feat_num - i - 1)
            # loss_distill += distillation_loss(s_feats[i], t_feats[i].detach(), getattr(self, 'margin%d' % (i+1))) \
            #                 / 2 ** (i + 1 - feat_num)

            if i < feat_num - 1:
                # loss_sepctral += F.mse_loss(self.fsp_matrix(s_feats[i], s_feats[i + 1]),self.fsp_matrix(t_feats[i].detach(), t_feats[i + 1].detach())) / 2 ** (feat_num - i - 1)
                # loss_sepctral += 0

                # print(self.fsp_matrix(s_feats[i], s_feats[i + 1]).size())
                # print(self.fsp_matrix(t_feats[i].detach(), t_feats[i + 1].detach()).size())

                # norm = torch.norm(s_feats[i],dim=(1,2)).unsqueeze(1)
                # print(norm)

                A_s = torch.bmm(self.fsp_matrix(s_feats[i], s_feats[i + 1]),self.fsp_matrix(s_feats[i], s_feats[i + 1]).transpose(2,1)) #for calculate the eigenvalue of fsp matrix, because fsp matrix is asymmetric
                A_t = torch.bmm(self.fsp_matrix(t_feats[i].detach(), t_feats[i + 1].detach()),self.fsp_matrix(t_feats[i].detach(), t_feats[i + 1].detach()).transpose(2,1))

                # print('teacher eigenvalue, student eigen, difference')
                # print(self.TopEigenvalue(K=A_s), self.TopEigenvalue(K=A_t), self.TopEigenvalue(K=A_s) - self.TopEigenvalue(K=A_t))

                # loss_spectral += F.mse_loss(self.TopEigenvalue(K=A_s), self.TopEigenvalue(K=A_t)) / 2 ** (feat_num - i - 1)
                loss_spectral += F.mse_loss(self.TopEigenvalue(K=A_s), self.TopEigenvalue(K=A_t)) / 2 ** (feat_num - i - 1) #the relation near the front layer is more valuable
                # print(F.mse_loss(self.TopEigenvalue(K=A_s), self.TopEigenvalue(K=A_s,n_power_iterations=400))) #观察power iteration的轮数是多少比较好
                #每一层的fsp loss的权重是不同的，前面层的权重更大一些, higher layer features are closer to the useful features for performing a main task.


        return s_out, loss_distill, loss_spectral
        #, loss_largest_eigenvalue